import UIKit

var greeting = "Hello, playground"
var number:Int = 5
for index in 1...5 {
    print("\(index) * \(number) = \(index*number)")
}

var totalNumbers = 100
var sum:Int = 0
for number in 1...totalNumbers {
    sum += number
}
print("The sum of first \(totalNumbers) is \(sum)")
var coreLang = ["Java","Swift","Javascript","ASP.net","SQL"]
//In Swift Array is declared using var arrayName=[]
for index in 0..<coreLang.count {
    print("\(coreLang[index])")
}
var totalSum = 10
for val in 1...totalSum {
    if (val%2 == 0) {
        print("\(val)",terminator:",")
    }
}
print(" are all even numbers")

var member=true
var scratchCard=10
var count=0
for attempt in 1..<scratchCard {
    count+=1
    if member {
        if count>3 {
            print("You won \(scratchCard-2)$")
            count=0
            break
        }
        
    }else{
        if(count>8){
            print("You got \(scratchCard-8)$")
        }
        
    }
}
var prodNumber:Int = 6
var product:Int = 1
print("The product of first \(prodNumber) numbers is",terminator:" ")

while prodNumber>0 {
    product*=prodNumber
    prodNumber-=1
}
print(product)

var rangeValue:Int = 30
while rangeValue >= 1 {
    if rangeValue%3 == 0 {
        print("\(rangeValue)",terminator:" ")
    }
    rangeValue-=1
}

print()
var number1 = 1
repeat {
    print(number,terminator:" ")
    number += 1
} while number <= 10

var number2 = 3
repeat {
    print("Hello World!!")
    number+=1
} while (number <= 2)

