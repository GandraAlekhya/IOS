//
//  ViewController.swift
//  Coordinatedemo
//
//  Created by Gandra,Alekhya on 3/1/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var ImageViewOutlet: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let minx = ImageViewOutlet.frame.minX;
        let miny = ImageViewOutlet.frame.minY;
        print(minx,"," , miny);
        
        let maxx = ImageViewOutlet.frame.maxX;
        let maxy =  ImageViewOutlet.frame.maxY;
        print(maxx,"," , maxy);
        
        let midx = ImageViewOutlet.frame.midX;
        let midy =  ImageViewOutlet.frame.midY;
        print(midx,"," , midy);
        
        ImageViewOutlet.frame.origin.x = 0
        ImageViewOutlet.frame.origin.y = 0
        
        ImageViewOutlet.frame.origin.x = 314
        ImageViewOutlet.frame.origin.y = 0
        
        ImageViewOutlet.frame.origin.x = 0
        ImageViewOutlet.frame.origin.y = 796
        
        ImageViewOutlet.frame.origin.x = 314
        ImageViewOutlet.frame.origin.y = 796
        
        ImageViewOutlet.frame.origin.x = 157
        ImageViewOutlet.frame.origin.y = 398
        
        
        
    }


}

