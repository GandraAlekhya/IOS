//
//  ViewController.swift
//  CourseApp
//
//  Created by Gandra,Alekhya on 2/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var crsNum: UILabel!
    
    @IBOutlet weak var crsTitle: UILabel!
    
    @IBOutlet weak var crsSemester: UILabel!
    
    @IBOutlet weak var previousButton: UIButton!
    
    @IBOutlet weak var nextButton: UIButton!
    
    let courses = [["img01","44555","Network Security","Fall2021"],
        ["img02","44643","IOS","Spring2022"],
        ["img03","44656","Streaming Data","Summer2022"]]
    
    var imageNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
      
        updateUI(imageNumber);
        previousButton.isEnabled = false;
        
        
    }


    
    @IBAction func previousButtonClicked(_ sender: Any) {
        //UI button should be updafes with previous course details
        //nexr button should be enabled
        nextButton.isEnabled = true
        imageNumber -= 1
        updateUI(imageNumber)
        //once reaching the start of the courses,previous button should be disabled.
        if(imageNumber == 0)
        {
            previousButton.isEnabled = false
        }
        
        
    }
    
    @IBAction func nextButtonClicked(_ sender: Any) {
        //UI should be updates with next course details
        imageNumber += 1;
        updateUI(imageNumber);
        
        //previous button should be enabled
        previousButton.isEnabled = true
        
        //once reaching the end of the courses array, next button should be disabled.
        if(imageNumber == courses.count - 1)
        {
            nextButton.isEnabled = false
            
        }
        
        
        
    }
    
    func updateUI(_ imageNumber: Int) {
        imageViewOutlet.image = UIImage(named:courses[imageNumber][0])
        crsNum.text = courses[imageNumber][1]
        crsNum.text = courses[imageNumber][2]
        crsSemester.text = courses[imageNumber][3]
    }
}

