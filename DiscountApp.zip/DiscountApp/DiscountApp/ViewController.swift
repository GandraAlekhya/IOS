//
//  ViewController.swift
//  DiscountApp
//
//  Created by Gandra,Alekhya on 2/15/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TextOutlet1: UITextField!
    
    @IBOutlet weak var TextOutlet2: UITextField!
    
    @IBOutlet weak var DisplayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        }

    @IBAction func SubmitClicked(_ sender: UIButton) {
        
        var a = Double(TextOutlet1.text!);
        
        
        var b = Double(TextOutlet2.text!)
        var dis  =  Double(b!*a!*0.01);
        
        var res = Double (a! - dis);
        DisplayLabel.text! = String (res);
        
        
    }
    
}

