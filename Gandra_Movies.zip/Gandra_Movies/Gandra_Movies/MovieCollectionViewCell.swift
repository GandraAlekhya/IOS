//
//  MovieCollectionViewCell.swift
//  Gandra_Movies
//
//  Created by Alekhya,Gandra on 4/27/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var movieCollectionView: UIImageView!
       
       func assignMovie(with movie:Movie){
              movieCollectionView.image = movie.image
          }
}
