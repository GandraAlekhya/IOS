//
//  MovieData.swift
//  Gandra_Movies
//
//  Created by Alekhya,Gandra on 4/27/22.
//


import Foundation
import UIKit

struct Movie {
    var title:String
    var image:UIImage
    var releasedYear:String
    var movieRating:String
    var boxOffice:String
    var moviePlot:String
    var cast:[String] = []
}
struct Genre {
    var category:String
    var movies:[Movie] = []
}

let category_type1: Genre = Genre(category: "Romantic", movies: [Movie(title: "Dear Comrade", image: UIImage(named: "Rimg1")!, releasedYear: "2019", movieRating: "8", boxOffice: "50 cr", moviePlot: "A hot-headed student union leader falls in love with a state-level cricketer; but soon, his anger issues become a roadblock on his way to unite with her.", cast: ["Vijay Devarakonda", "Rashmika"]), Movie(title: "Em maya chesave", image: UIImage(named: "Rimg2")!, releasedYear: "2008", movieRating: "6", boxOffice: "15 cr", moviePlot: "Karthik, a Hindu engineering graduate, wants to become a film director; he falls in love with Jessie, his Christian neighbour, but her father opposes their relationship due to religious differences.", cast: ["Naga Chaitanya", "Samantha"]), Movie(title: "Majili", image: UIImage(named: "Rimg3")!, releasedYear: "2017", movieRating: "5.5", boxOffice: "60 cr", moviePlot: "A former cricket player nursing his wounds of a failed relationship takes up the task of training his ex-lover's daughter and in the process discovers his feelings towards his wife and her unrequited love for him.", cast: ["Naga Chaitanya", "Samantha"]), Movie(title: "Eega", image: UIImage(named: "Rimg4")!, releasedYear: "2012", movieRating: "6.5", boxOffice: "80 cr", moviePlot: "A man loves a woman but is killed by another jealous man, who lusts after the woman. He is reincarnated as a fly and decides to avenge his death. He teams up with the woman to make the murderer's life a living hell. ", cast: ["Nani", "Samantha"]), Movie(title: "Uppena", image: UIImage(named: "Rimg5")!, releasedYear: "2019", movieRating: "4.7", boxOffice: "90 cr", moviePlot: "A fisherman falls for the daughter of a local businessman, but they face violent opposition from the girl's old-fashioned father.", cast: ["Panja Vaisshnav Tej", "KritiShetty"])])

let category_type2: Genre = Genre(category: "Comedy", movies: [Movie(title: "Jathi Ratnalu", image: UIImage(named: "Cimg1")!, releasedYear: "2019", movieRating: "6.0", boxOffice: "100 cr", moviePlot: "After being released from prison, three men start to plan their lives on the outside, searching for love and happiness.", cast: ["Naveen Polishetty", "Faria Abdullah"]), Movie(title: "Pressure Cooker", image: UIImage(named: "Cimg2")!, releasedYear: "2009", movieRating: "4.5", boxOffice: "14 crore", moviePlot: "A man pressures his son to become successful in America", cast: ["Sai Ronak", "Preethi Asrani"]), Movie(title: "Kick", image: UIImage(named: "Cimg3")!, releasedYear: "2005", movieRating: "5.5", boxOffice: "112 cr", moviePlot: "A young man does dangerous things for thrills, so he doesn't stay in one job for long. His girlfriend breaks up with him because of it, and he resorts to robbery -- but with a cause.", cast: ["Ravi Teja", "Ileana"]), Movie(title: "Cycle", image: UIImage(named: "Cimg4")!, releasedYear: "2012", movieRating: "5.0", boxOffice: "55 cr", moviePlot: "An astrologer's search for his prized bicycle turns into a journey of self-realisation, while the thieves learn a few lessons of their own.", cast: ["Mahat Raghavendra", "Swetha Varma"]), Movie(title: "Pagal", image: UIImage(named: "Cimg5")!, releasedYear: "2020", movieRating: "7.7", boxOffice: "4.23 cr", moviePlot: "Prem desperately searches for someone to love after the death of his mother, until Cupid's arrow finally connects.", cast: ["Vishwak Sen", "Nivetha Pethuraj"])])

let category_type3: Genre = Genre(category: "Horror", movies: [Movie(title: "Pisachi", image: UIImage(named: "Himg1")!, releasedYear: "2014", movieRating: "5.5", boxOffice: "47 cr", moviePlot: "A violinist experiences paranormal experience in his flat after a death of a girl who he tries to save due to accident. Later he realises that actually the spirit is helping him and he tries to find out who killed the girl by accident", cast: ["Naga Raj Kumar", "Kalyani Natarajan"]), Movie(title: "Anabelle", image: UIImage(named: "Himg2")!, releasedYear: "2006", movieRating: "4.7", boxOffice: "10 cr", moviePlot: "John Form (Ward Horton) thinks he's found the perfect gift for his expectant wife, Mia (Annabelle Wallis) : a vintage doll in a beautiful white dress. However, the couple's delight doesn't last long: One terrible night, devil worshippers invade their home and launch a violent attack against the couple. When the cultists try to summon a demon, they smear a bloody rune on the nursery wall and drip blood on Mia's doll, thereby turning the former object of beauty into a conduit for ultimate evil.", cast: ["Ward Horton", "Kajol"]), Movie(title: "Papa", image: UIImage(named: "Himg3")!, releasedYear: "2016", movieRating: "5.7", boxOffice: "32 cr", moviePlot: "A young man searching for his birth parents learns his mother is dead and his father lives in a home for mentally challenged individuals.", cast: ["Ben Freidman", "Nivetha Thomas"]), Movie(title: "Nishabdam", image: UIImage(named: "Himg4")!, releasedYear: "2015", movieRating: "5.9", boxOffice: "24 cr", moviePlot: "Seattle PD investigates the murder of a man and Sakshi, a deaf and mute artist, and her husband Antony, a renowned cello player, are related to it.", cast: ["Antony", "Anushka"]), Movie(title: "Raju gari gadha", image: UIImage(named: "Himg5")!, releasedYear: "2019", movieRating: "6.9", boxOffice: "11 cr", moviePlot: "Seven contestants take part in a reality TV show in a haunted house.", cast: ["Ashwin Babu","Dhanya Balakrishna"])])


let Stack = [category_type1, category_type2, category_type3]
