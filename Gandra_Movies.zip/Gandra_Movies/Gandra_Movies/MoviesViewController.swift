
//
//  MoviesViewController.swift
//  Gandra_Movies
//
//  Created by Alekhya,Gandra on 4/27/22.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return MoviesList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionViewOutlet.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        cell.assignMovie(with: MoviesList[indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignMovieDetails(index: indexPath)
    }
    
    @IBOutlet weak var collectionViewOutlet: UICollectionView!
    @IBOutlet weak var movieNameLabel: UILabel!
    @IBOutlet weak var movieRatingLabel: UILabel!
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    @IBOutlet weak var movieYearLabel: UILabel!
    @IBOutlet weak var moviePlotLabel: UILabel!
    @IBOutlet weak var movieCastLabel: UILabel!
    
    var MoviesList : [Movie] = []
    var title_Category = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = title_Category
        collectionViewOutlet.delegate = self
        collectionViewOutlet.dataSource = self
    }
    func assignMovieDetails(index: IndexPath){
        movieNameLabel.text = "Movie Name : \(MoviesList[index.row].title)"
        movieRatingLabel.text = "Movie Rating : \(MoviesList[index.row].movieRating)"
        movieBoxOfficeLabel.text = "Box Office Collection : \(MoviesList[index.row].boxOffice)"
        movieYearLabel.text = "Movie Year : \(MoviesList[index.row].releasedYear)"
        moviePlotLabel.text = "Movie Plot : \(MoviesList[index.row].moviePlot)"
        movieCastLabel.text = "Movie Cast : "
        for i in (MoviesList[index.row].cast){
            movieCastLabel.text! += "\(i), "
        }
    }
    
}
