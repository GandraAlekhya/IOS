//
//  ViewController.swift
//  Gandra_SearchApp
//
//  Created by student on 3/3/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchOption: UIButton!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var prevImage: UIButton!
    @IBOutlet weak var nextImage: UIButton!
    
    @IBOutlet weak var topicinfoText: UITextView!
    
 
    @IBOutlet weak var resetAction: UIButton!
    
    var imageNumber = 0;
    var topic: Int = -1
    var count1 : Int = -1
    var arr = [
               ["Aimg1","Aimg2","Aimg3","Aimg4","Aimg5"],
               ["Animg1","Animg2","Animg3","Animg4","Animg5"],
               ["Fimg1","Fimg2","Fimg3","Fimg4","Fimg5"]]
    
    var actor_keywords = ["Actor","Actors","prabhas","NTR","Vijay" , "Nani" , "Chiranjeevi"]
    var animal_keywords = ["animal","animals","Rabbit","Lion","Elephant","Monkey","Dog"]
    var flowers_keywords = ["Rose","SunFlower","Lily","Tulip","Jasmine"]
    var topics_array = [["Uppalapati Venkata Suryanarayana Prabhas Raju (born 23 October 1979), known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema","Nandamuri Taraka Rama Rao Jr. (born 20 May 1983), also known as Jr NTR or Tarak, is an Indian actor, singer, and television presenter who works in Telugu cinema.","Deverakonda has established himself as a leading actor of Telugu cinema by starring in films such as Arjun Reddy (2017), Mahanati (2018), Geetha Govindam (2018), Taxiwaala (2018) and Dear Comrade (2019). ","Ghanta Naveen Babu (born 24 February 1984), known professionally as Nani, is an Indian actor, producer, and television presenter primarily known for his work in Telugu cinema","Chiranjeevi (born Konidela Siva Sankara Vara Prasad; 22 August 1955) is an Indian actor and former politician, who predominantly works in Telugu cinema."],
        ["Rabbits, also known as bunnies or bunny rabbits, are small mammals in the family Leporidae (which also contains the hares) of the order Lagomorpha","The lion (Panthera leo) is a large cat of the genus Panthera native to Africa and India. It has a muscular, deep-chested body, short, rounded head, round ears, and a hairy tuft at the end of its tail.","Elephants are the largest existing land animals. Three living species are currently recognised: the African bush elephant, the African forest elephant, and the Asian elephant. ","Monkey is a common name that may refer to most mammals of the infraorder Simiiformes, also known as the simians. Traditionally, all animals in the group now known as simians are counted as monkeys except the apes, a grouping known as paraphyletic","The dog or domestic dog (Canis familiaris[5][6] or Canis lupus familiaris[6]) is a domesticated descendant of the wolf which is characterized by an upturning tail. "],
        ["The name Rose is of Latin origin and means 'rose, a flower. It derives from the Latin word rosa, meaning 'a flower.' It is thought to originally be the Norman form of the Germanic name Hrodohaidis, meaning 'famous type'.","The common name, “sunflower”, typically refers to the popular annual species Helianthus annuus, or the common sunflower, whose round flower heads in combination with the ligules look like the glowing sun. In Greek, helios means sun and anthos means flower, thus the name Sunflower.","Lilium is a genus of herbaceous flowering plants growing from bulbs, all with large prominent flowers. They are the true lilies. ","Tulips (Tulipa) are a genus of spring-blooming perennial herbaceous bulbiferous geophytes (having bulbs as storage organs). The flowers are usually large, showy and brightly colored, generally red, pink, yellow, or white (usually in warm colors).","The main reason jasmine is so famous is its strong fragrance. People adore the flower for its strong, sweet smell. Countless cultures worldwide include it in aromatic products like candles, perfumes, soaps, and lotions."]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        searchOption.isEnabled = false
        nextImage.isHidden = true
        prevImage.isHidden = true
        resetAction.isHidden = true
        resultImage.image = UIImage(named: "default")

        //On Loading the app we need to display default Image
    }


    @IBAction func searchFieldAction(_ sender: Any) {
        searchOption.isEnabled = true
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        if(actor_keywords.contains(searchTextField.text!)){
            topic = 0
            imageNumber = 0
            buttonsDisable()
        }
        else if(animal_keywords.contains(searchTextField.text!)){
            topic = 1
            imageNumber = 0
            buttonsDisable()
        }
        else if(flowers_keywords.contains(searchTextField.text!)){
            topic = 2
            imageNumber = 0;
            buttonsDisable()
        }
        else{
            topic = -1
            resultImage.image = UIImage(named: "default")
            topicinfoText.text = "No matches with the given Key words. Please try again."
            resetAction.isHidden = true
            nextImage.isHidden = true
            prevImage.isHidden = true
        }
        
        if(topic != -1)
        {
            prevImage.isEnabled = false
            nextImage.isEnabled = true
            count1 = arr[topic].count
            resultImage.image = UIImage(named: arr[topic][0])
            topicinfoText.text = topics_array[topic][0]
        }
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
            nextImage.isEnabled = true;
            imageNumber -= 1
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicinfoText.text = topics_array[topic][imageNumber]
            if(imageNumber == 0){
                        prevImage.isEnabled = false
                }
    
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
            prevImage.isEnabled = true
            imageNumber += 1
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicinfoText.text = topics_array[topic][imageNumber]
            if(imageNumber == count1-1){
                nextImage.isEnabled = false
            }
    }
    
    @IBAction func resetButton(_ sender: Any) {
        nextImage.isHidden = true
        prevImage.isHidden = true
        resetAction.isHidden = true
        searchTextField.text = ""
        searchOption.isEnabled = false
        topicinfoText.text = ""
        resultImage.image = UIImage(named: "default")
        
    }
    func buttonsDisable(){
        nextImage.isHidden = false
        prevImage.isHidden = false
        resetAction.isHidden = false
    }
    


}








