//
//  ViewController.swift
//  Gandra_SearchApp
//
//  Created by Gandra,Alekhya on 3/3/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    
    @IBAction func serachButtonAction(_ sender: Any) {
    }
    
    @IBOutlet weak var ResultImage: UIImageView!
    
   
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
    }
    
    
    @IBAction func showNextImagesBtn(_ sender: Any) {
    }
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    
    @IBAction func resetButton(_ sender: Any) {
    }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

