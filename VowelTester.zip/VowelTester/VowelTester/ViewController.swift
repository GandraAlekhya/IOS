//
//  ViewController.swift
//  VowelTester
//
//  Created by Gandra,Alekhya on 1/25/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textOutlet: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClicked(_ sender: UIButton) {
        //read the text
        var enteredtext =  textOutlet.text!
        //check for vowels
        if (enteredtext.contains("a") ||
            enteredtext.contains("e") ||
            enteredtext.contains("i") ||
            enteredtext.contains("o") ||
            enteredtext.contains("u")) {
                displayLabel.text = "The eneterd text contains vowel"
                
            }
        else{
            displayLabel.text = "The eneterd text does not contains vowel"
        }
        
    }
    
}

